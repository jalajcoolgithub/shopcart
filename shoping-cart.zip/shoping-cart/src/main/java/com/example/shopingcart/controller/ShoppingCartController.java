package com.example.shopingcart.controller;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.shopingcart.model.Item;
import com.example.shopingcart.service.CartService;

@RestController
@RequestMapping("/rest")
public class ShoppingCartController {

	Logger logger = LoggerFactory.getLogger(ShoppingCartController.class);

	@Autowired
	CartService cartService;

	@PostMapping("/addItem")
	public String addToCart(@RequestBody Item item) {
		logger.info(item.getItemName() + " is adding to cart....");
		cartService.addToCart(item);
		logger.info(item.getItemName() + " is added to cart....");
		return "item added successfully";
	}

	@GetMapping(path="/allItems")
	public ResponseEntity<List<Item>> getAllItems() {
		List<Item> items = cartService.getAllItems();
	    Collections.sort(items,(o1, o2) -> {
			return o1.getItemPrice().compareTo(o2.getItemPrice());
		});
	    return ResponseEntity.ok(items);
	}

	
	@GetMapping(value = "/removeItemFromCart/{itemId}")
	public String removeItems(@PathVariable("itemId") Integer itemId) {
		cartService.removeItem(itemId);
		return "item deleted successfully"; 
	}

}
