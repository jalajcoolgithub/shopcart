package com.example.shopingcart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.shopingcart.model.Item;
import com.example.shopingcart.repository.CartRepository;

@Service
public class CartService {

	@Autowired
	CartRepository cartRepository;

	public void addToCart(Item item) {
		cartRepository.save(item);
	}

	public List<Item> getAllItems() {
		return cartRepository.findAll();

	}

	public void removeItem(Integer itemId) {
		cartRepository.deleteById(itemId);
	}

}
